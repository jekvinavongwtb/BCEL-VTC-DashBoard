import { useState, useCallback, useRef } from "react";
import * as XLSX from "xlsx";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis
} from "recharts";

// ─── theme ───────────────────────────────────────────────────────────
const BG = "#060D1A";
const CARD = "#0C1525";
const BORDER = "#172035";
const ACCENT = "#00D4FF";
const GREEN = "#00E676";
const RED = "#FF5252";
const GOLD = "#FFD740";
const DIM = "#3A5070";
const TEXT = "#D0E8F8";

const pctColor = (p) => (p >= 0.1667 ? GREEN : p >= 0.10 ? GOLD : RED);
const fmt = (n) => typeof n === "number" ? n.toLocaleString() : (n ?? "-");
const pctFmt = (p) => `${(+p * 100).toFixed(1)}%`;

// ─── parse helpers ────────────────────────────────────────────────────
function parseSummarySheet(wb) {
  const ws = wb.Sheets["ຕົວເລກສຸດທິທຽບແຜນ(ແບ່ງໜ່ວຍ)"];
  if (!ws) return null;
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
  // row[1] = branch codes, row[2] = headers, row[3..] = product rows
  const branchRow = rows[1] || [];
  const branches = [];
  for (let c = 1; c < branchRow.length; c += 2) {
    if (branchRow[c] && String(branchRow[c]).trim() !== "") {
      branches.push({ id: String(branchRow[c]).trim(), col: c });
    }
  }
  const productRows = rows.slice(3).filter(r => r[0]);
  return { branches, productRows };
}

function parseKPISheet(wb) {
  const ws = wb.Sheets["KPI"];
  if (!ws) return [];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r[0] || typeof r[0] !== "number") continue;
    out.push({
      rank: r[0],
      id: String(r[1] ?? ""),
      kpiScore: +r[2] || 0,
      kpiPlan: +r[5] || 0,
    });
  }
  return out;
}

// ກຸ່ມຜະລິດຕະພັນສຳລັບຈັດໝວດ
const GROUP_PAYMENT = ["ຊໍາລະສະສາງ", "BCEL Onepay", "EDC"];

function parseProductSheet(wb) {
  const ws = wb.Sheets["ສະເພາະຜະລິດຕະພັນ"];
  if (!ws) return [];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
  const out = [];
  for (let i = 2; i < rows.length; i++) {
    const r = rows[i];
    if (!r[0] || typeof r[0] !== "string") continue;
    const name = String(r[0]).trim();
    if (!name) continue;
    const actual = +r[1] || 0;
    const plan   = +r[2] || 0;
    const pct    = isNaN(+r[3]) ? 0 : +r[3];
    const group  = GROUP_PAYMENT.some(g => name.includes(g) || g.includes(name))
      ? "ຊໍາລະສະສາງ" : "ຜະລິດຕະພັນອື່ນ";
    out.push({ name, actual, plan, pct, group });
  }
  return out;
}

function parseBranchSheet(wb, sheetName) {
  const ws = wb.Sheets[sheetName];
  if (!ws) return null;
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
  const products = [];
  for (let i = 2; i < rows.length; i++) {
    const r = rows[i];
    if (!r[0] || typeof r[0] !== "string") continue;
    const name = String(r[0]).trim();
    if (!name) continue;
    const plan = +r[1] || 0;
    const isPayment = GROUP_PAYMENT.some(g => name.includes(g) || g.includes(name));
    // ຊໍາລະ/Onepay/EDC: actual=col27(ຜົນລວມ), pct=col29, status=col30
    // ສຳລັບ ຊໍາລະສະສາງ (parent row) actual ຢູ່ col27 ເຊັ່ນດຽວກັນ
    // ກວດ col27/28/29/30 ຕາມ pattern ທີ່ scan ມາ
    let actual = 0, pct = 0, status = "";
    // try col27 as cumulative actual
    const v27 = r[27]; const v28 = r[28]; const v29 = r[29]; const v30 = r[30];
    actual = (typeof v27 === "number" && !isNaN(v27)) ? v27
           : (typeof v28 === "number" && !isNaN(v28)) ? v28 : 0;
    pct    = (typeof v29 === "number" && !isNaN(v29)) ? v29
           : (typeof v30 === "number" && !isNaN(v30)) ? v30 : 0;
    // status string ຢູ່ col30 ຫຼື col31
    const s30 = r[30] ? String(r[30]).trim() : "";
    const s31 = r[31] ? String(r[31]).trim() : "";
    status = (s30 === "ເກີນແຜນ" || s30 === "ຫຼຸດແຜນ") ? s30
           : (s31 === "ເກີນແຜນ" || s31 === "ຫຼຸດແຜນ") ? s31 : "";
    const group = GROUP_PAYMENT.some(g => name.includes(g) || g.includes(name))
      ? "ຊໍາລະສະສາງ" : "ຜະລິດຕະພັນອື່ນ";
    products.push({ name, plan, actual, pct, status, group });
  }
  return { sheetName, products };
}

function processWorkbook(wb) {
  const kpiList = parseKPISheet(wb);
  const products = parseProductSheet(wb);
  const summary = parseSummarySheet(wb);

  // Build branch list from KPI sheet + branch sheets
  const branchSheets = wb.SheetNames.filter(s => /^\d{3}/.test(s));
  const branches = kpiList.map(k => {
    const sheetName = branchSheets.find(s => s.startsWith(k.id)) || "";
    const detail = sheetName ? parseBranchSheet(wb, sheetName) : null;
    return { ...k, sheetName, detail };
  });

  const kpiTotal = kpiList.reduce((s, b) => s + b.kpiScore, 0);
  const kpiPlan = kpiList.length > 0 ? kpiList[0].kpiPlan : 0;
  const totalKpiPlan = kpiList.reduce((s,b)=>s+b.kpiPlan,0);

  return { branches, products, kpiTotal, totalKpiPlan };
}

// ─── sub-components ───────────────────────────────────────────────────
const Pill = ({ label, color }) => (
  <span style={{ fontSize: 9, padding: "2px 8px", borderRadius: 20, background: `${color}22`, color, fontWeight: 700, letterSpacing: 1 }}>{label}</span>
);

const MiniProgress = ({ pct, color }) => (
  <div style={{ width: "100%", height: 5, background: BORDER, borderRadius: 3, overflow: "hidden", marginTop: 4 }}>
    <div style={{ width: `${Math.min(pct * 100, 100)}%`, height: "100%", background: color, borderRadius: 3, boxShadow: `0 0 8px ${color}88` }} />
  </div>
);

const StatCard = ({ label, value, sub, accent }) => (
  <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "16px 18px", borderLeft: `3px solid ${accent}` }}>
    <div style={{ fontSize: 10, color: DIM, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{label}</div>
    <div style={{ fontSize: 26, fontWeight: 900, color: accent, fontFamily: "monospace", lineHeight: 1 }}>{value}</div>
    {sub && <div style={{ fontSize: 10, color: DIM, marginTop: 4 }}>{sub}</div>}
  </div>
);

// ─── Upload Screen ────────────────────────────────────────────────────
function UploadScreen({ onLoad }) {
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef();

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: "array" });
        const data = processWorkbook(wb);
        onLoad(data, file.name);
      } catch (err) {
        setError("ອ່ານໄຟລບໍ່ໄດ້: " + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div style={{ minHeight: "100vh", background: BG, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 32 }}>
      <div style={{ marginBottom: 32, textAlign: "center" }}>
        <div style={{ fontSize: 11, color: ACCENT, letterSpacing: 4, marginBottom: 8 }}>BCEL · ນະຄອນຫຼວງ</div>
        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900, color: TEXT }}>KPI Dashboard 2026</h1>
        <div style={{ fontSize: 12, color: DIM, marginTop: 6 }}>ອັບໂຫລດໄຟລ Excel ເພື່ອເລີ່ມຕົ້ນ</div>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); handleFile(e.dataTransfer.files[0]); }}
        onClick={() => inputRef.current.click()}
        style={{
          width: 360, maxWidth: "90vw",
          border: `2px dashed ${dragging ? ACCENT : BORDER}`,
          borderRadius: 16,
          padding: "48px 32px",
          textAlign: "center",
          cursor: "pointer",
          background: dragging ? `${ACCENT}08` : CARD,
          transition: "all 0.2s",
        }}
      >
        <div style={{ fontSize: 40, marginBottom: 16 }}>📊</div>
        <div style={{ fontSize: 14, color: TEXT, fontWeight: 700, marginBottom: 8 }}>ລາກໄຟລ Excel ມາວາງ</div>
        <div style={{ fontSize: 11, color: DIM, marginBottom: 20 }}>ຫຼື ກົດເພື່ອເລືອກໄຟລ</div>
        <div style={{ fontSize: 10, color: DIM, padding: "8px 16px", background: "#0A1424", borderRadius: 8, display: "inline-block" }}>
          .xlsx · ຕ_ດຕາມຕ_ວເລກ...xlsx
        </div>
        <input ref={inputRef} type="file" accept=".xlsx,.xls" style={{ display: "none" }} onChange={(e) => handleFile(e.target.files[0])} />
      </div>

      {error && <div style={{ marginTop: 16, color: RED, fontSize: 12 }}>{error}</div>}

      <div style={{ marginTop: 40, display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, maxWidth: 500, width: "100%" }}>
        {[["📂", "Upload Excel", "ໄຟລຕ້ນສະບັບ BCEL"], ["🔄", "ອ່ານອັດຕະໂນມັດ", "ວິເຄາະທຸກ Sheet"], ["📈", "Dashboard", "KPI, ສາຂາ, ຜະລິດຕະພັນ"]].map(([icon, t, s], i) => (
          <div key={i} style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "14px 12px", textAlign: "center" }}>
            <div style={{ fontSize: 22, marginBottom: 6 }}>{icon}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: TEXT, marginBottom: 2 }}>{t}</div>
            <div style={{ fontSize: 9, color: DIM }}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────
export default function App() {
  const [data, setData] = useState(null);
  const [fileName, setFileName] = useState("");
  const [tab, setTab] = useState("overview");
  const [selectedBranch, setSelectedBranch] = useState(null);
  const fileInputRef = useRef();

  const handleLoad = useCallback((d, name) => {
    setData(d);
    setFileName(name);
    setTab("overview");
    setSelectedBranch(null);
  }, []);

  if (!data) return <UploadScreen onLoad={handleLoad} />;

  const { branches, products, kpiTotal, totalKpiPlan } = data;
  const kpiPct = totalKpiPlan > 0 ? kpiTotal / totalKpiPlan : 0;
  const sortedBranches = [...branches].sort((a, b) => b.kpiScore - a.kpiScore);

  const tabBtn = (t, label) => (
    <button onClick={() => setTab(t)} style={{
      padding: "8px 18px", border: "none", cursor: "pointer",
      fontFamily: "monospace", fontSize: 12, fontWeight: 700, letterSpacing: 1, borderRadius: 6,
      background: tab === t ? ACCENT : "transparent",
      color: tab === t ? BG : DIM, transition: "all 0.2s",
    }}>{label}</button>
  );

  return (
    <div style={{ background: BG, minHeight: "100vh", color: TEXT, fontFamily: "monospace", padding: "20px 24px" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, borderBottom: `1px solid ${BORDER}`, paddingBottom: 18 }}>
        <div>
          <div style={{ fontSize: 10, color: ACCENT, letterSpacing: 3, marginBottom: 2, fontWeight: 700 }}>BCEL · ສາຂານະຄອນຫຼວງ</div>
          <h1 style={{ margin: 0, fontSize: 20, fontWeight: 900, color: TEXT }}>ລາຍງານ KPI ປະຈຳປີ 2026</h1>
          <div style={{ fontSize: 9, color: DIM, marginTop: 2 }}>📁 {fileName}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 9, color: DIM }}>KPI ລວມ</div>
            <div style={{ fontSize: 26, fontWeight: 900, color: GOLD, lineHeight: 1 }}>{fmt(kpiTotal)}</div>
            <div style={{ fontSize: 9, color: DIM }}>{pctFmt(kpiPct)} ຂອງແຜນ</div>
          </div>
          <button
            onClick={() => fileInputRef.current.click()}
            style={{ padding: "8px 14px", background: `${ACCENT}15`, border: `1px solid ${ACCENT}55`, borderRadius: 8, color: ACCENT, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "monospace" }}
          >🔄 ປ່ຽນໄຟລ</button>
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls" style={{ display: "none" }} onChange={(e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
              try {
                const wb = XLSX.read(ev.target.result, { type: "array" });
                handleLoad(processWorkbook(wb), file.name);
              } catch {}
            };
            reader.readAsArrayBuffer(file);
          }} />
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 22 }}>
        {tabBtn("overview", "ພາບລວມ")}
        {tabBtn("branches", `ໜ່ວຍ (${branches.length})`)}
        {tabBtn("products", "ຜະລິດຕະພັນ")}
        {selectedBranch && tabBtn("detail", `📍 ${selectedBranch.id}`)}
      </div>

      {/* ── OVERVIEW ── */}
      {tab === "overview" && (
        <div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 20 }}>
            <StatCard label="ສາຂາທັງໝົດ" value={branches.length} sub="ໜ່ວຍບໍລິການ VTE" accent={ACCENT} />
            <StatCard label="ຄະແນນ KPI" value={pctFmt(kpiPct)} sub={`${fmt(kpiTotal)} / ${fmt(totalKpiPlan)}`} accent={GOLD} />
            <StatCard label="ສາຂາ #1" value={sortedBranches[0]?.id ?? "-"} sub={`${fmt(sortedBranches[0]?.kpiScore)} ຄະແນນ`} accent={GREEN} />
            <StatCard label="ຜະລິດຕະພັນ" value={products.length} sub="ລາຍການທັງໝົດ" accent={ACCENT} />
          </div>

          {/* KPI bar */}
          <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "18px 20px", marginBottom: 18 }}>
            <div style={{ fontSize: 10, color: DIM, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>ຄະແນນ KPI ຕາມໜ່ວຍ (Ranking)</div>
            <ResponsiveContainer width="100%" height={210}>
              <BarChart data={sortedBranches} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="id" tick={{ fill: DIM, fontSize: 11 }} axisLine={{ stroke: BORDER }} tickLine={false} />
                <YAxis tick={{ fill: DIM, fontSize: 10 }} axisLine={{ stroke: BORDER }} tickLine={false} />
                <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8, fontSize: 11 }}
                  formatter={(v, n) => [fmt(v), "KPI"]} />
                <Bar dataKey="kpiScore" radius={[4, 4, 0, 0]}>
                  {sortedBranches.map((b, i) => (
                    <Cell key={i} fill={i === 0 ? GOLD : i < 3 ? ACCENT : "#1A3A5A"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* KPI % bar */}
          <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "18px 20px" }}>
            <div style={{ fontSize: 10, color: DIM, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>ອັດຕາ KPI ທຽບແຜນ (%)</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={sortedBranches.map(b => ({ id: b.id, pct: b.kpiPlan > 0 ? +(b.kpiScore / b.kpiPlan * 100).toFixed(1) : 0, raw: b.kpiScore / (b.kpiPlan || 1) }))}
                margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="id" tick={{ fill: DIM, fontSize: 11 }} axisLine={{ stroke: BORDER }} tickLine={false} />
                <YAxis tick={{ fill: DIM, fontSize: 10 }} axisLine={{ stroke: BORDER }} tickLine={false} unit="%" />
                <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8, fontSize: 11 }}
                  formatter={(v) => [`${v}%`, "ອັດຕາ KPI"]} />
                <Bar dataKey="pct" radius={[4, 4, 0, 0]}>
                  {sortedBranches.map((b, i) => (
                    <Cell key={i} fill={pctColor(b.kpiScore / (b.kpiPlan || 1))} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* ── BRANCHES ── */}
      {tab === "branches" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 14 }}>
          {sortedBranches.map((b, rank) => {
            const kPct = b.kpiPlan > 0 ? b.kpiScore / b.kpiPlan : 0;
            const color = pctColor(kPct);
            const isSelected = selectedBranch?.id === b.id;
            return (
              <div key={b.id}
                onClick={() => { setSelectedBranch(b); setTab("detail"); }}
                style={{
                  background: isSelected ? "#0A1930" : CARD,
                  border: `1px solid ${isSelected ? ACCENT : BORDER}`,
                  borderRadius: 12, padding: "16px 18px", cursor: "pointer", transition: "all 0.2s",
                }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div>
                    <div style={{ fontSize: 9, color, letterSpacing: 2, marginBottom: 2 }}>#{rank + 1} RANK</div>
                    <div style={{ fontWeight: 800, fontSize: 13, color: TEXT }}>{b.id}</div>
                    <div style={{ fontSize: 10, color: DIM }}>{b.sheetName.replace(/^\d+\s*/, "")}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 22, fontWeight: 900, color, lineHeight: 1 }}>{pctFmt(kPct)}</div>
                    <div style={{ fontSize: 9, color: DIM }}>ທຽບແຜນ</div>
                  </div>
                </div>
                <MiniProgress pct={kPct} color={color} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginTop: 12 }}>
                  <div>
                    <div style={{ fontSize: 9, color: DIM }}>KPI ຄະແນນ</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: GOLD }}>{fmt(b.kpiScore)}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 9, color: DIM }}>ແຜນ KPI</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: DIM }}>{fmt(b.kpiPlan)}</div>
                  </div>
                </div>
                <div style={{ marginTop: 10, fontSize: 9, color: DIM, textAlign: "right" }}>👆 ກົດເພື່ອເບິ່ງລາຍລະອຽດ</div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── PRODUCTS ── */}
      {tab === "products" && (() => {
        const mainProds = products.filter(p => p.group !== "ຊໍາລະສະສາງ");
        const payProds  = products.filter(p => p.group === "ຊໍາລະສະສາງ");
        const ProductTable = ({ rows, title, accent }) => (
          <div style={{ background: CARD, border: `1px solid ${accent || BORDER}`, borderRadius: 12, overflow: "hidden", marginBottom: 18 }}>
            <div style={{ padding: "12px 18px", borderBottom: `1px solid ${BORDER}`, display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 3, height: 16, background: accent || DIM, borderRadius: 2 }} />
              <div style={{ fontSize: 11, color: accent || DIM, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700 }}>{title}</div>
              <span style={{ marginLeft: "auto", fontSize: 10, color: DIM }}>{rows.length} ລາຍການ</span>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#0A1424" }}>
                  {["ຜະລິດຕະພັນ","ປະຕິບັດ","ແຜນ","ອັດຕາ","ສະຖານະ"].map((h,i)=>(
                    <th key={i} style={{ padding:"9px 16px", textAlign:i===0?"left":"right", fontSize:9, color:DIM, letterSpacing:1, textTransform:"uppercase", fontWeight:700 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((p, i) => {
                  const c = pctColor(p.pct);
                  return (
                    <tr key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                      <td style={{ padding:"9px 16px", fontSize:12, color:"#C0D8E8" }}>{p.name}</td>
                      <td style={{ padding:"9px 16px", textAlign:"right", fontSize:12, fontWeight:700, color:TEXT }}>{fmt(p.actual)}</td>
                      <td style={{ padding:"9px 16px", textAlign:"right", fontSize:12, color:DIM }}>{fmt(p.plan)}</td>
                      <td style={{ padding:"9px 16px", textAlign:"right", fontSize:13, fontWeight:900, color:c }}>{pctFmt(p.pct)}</td>
                      <td style={{ padding:"9px 16px", textAlign:"right" }}><Pill label={p.pct>=0.1667?"ເກີນ":"ຫຼຸດ"} color={c} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        );
        return (
          <div>
            <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "18px 20px", marginBottom: 18 }}>
              <div style={{ fontSize: 10, color: DIM, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>ອັດຕາປະຕິບັດທຸກຜະລິດຕະພັນ</div>
              <ResponsiveContainer width="100%" height={Math.max(260, products.length * 28)}>
                <BarChart data={products} layout="vertical" margin={{ top:0, right:60, left:20, bottom:0 }}>
                  <XAxis type="number" tickFormatter={v=>`${(v*100).toFixed(0)}%`} tick={{ fill:DIM, fontSize:10 }} axisLine={{ stroke:BORDER }} tickLine={false} />
                  <YAxis type="category" dataKey="name" width={140} tick={{ fill:"#A0B8C8", fontSize:10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background:CARD, border:`1px solid ${BORDER}`, borderRadius:8, fontSize:11 }} formatter={(v)=>[`${(v*100).toFixed(1)}%`,"ອັດຕາ"]} />
                  <Bar dataKey="pct" radius={[0,4,4,0]}>
                    {products.map((p,i)=><Cell key={i} fill={pctColor(p.pct)} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            {payProds.length > 0 && (
              <div style={{ marginBottom: 6 }}>
                <div style={{ fontSize:11, color:ACCENT, letterSpacing:3, marginBottom:12, textTransform:"uppercase", fontWeight:700 }}>
                  💳 ຊໍາລະສະສາງ — Onepay &amp; EDC
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12, marginBottom:14 }}>
                  {payProds.map((p,i)=>{
                    const c=pctColor(p.pct);
                    return (
                      <div key={i} style={{ background:CARD, border:`1px solid ${c}44`, borderRadius:10, padding:"14px 16px" }}>
                        <div style={{ fontSize:10, color:DIM, marginBottom:4 }}>{p.name}</div>
                        <div style={{ fontSize:22, fontWeight:900, color:c }}>{pctFmt(p.pct)}</div>
                        <div style={{ fontSize:10, color:DIM, marginTop:4 }}>{fmt(p.actual)} / {fmt(p.plan)}</div>
                        <MiniProgress pct={p.pct} color={c} />
                      </div>
                    );
                  })}
                </div>
                <ProductTable rows={payProds} title="ຊໍາລະສະສາງ" accent={ACCENT} />
              </div>
            )}
            <ProductTable rows={mainProds} title="ຜະລິດຕະພັນທົ່ວໄປ" accent={GOLD} />
          </div>
        );
      })()}


      {/* ── BRANCH DETAIL ── */}
      {tab === "detail" && selectedBranch && (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
            <button onClick={() => setTab("branches")} style={{ background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, padding: "6px 12px", color: DIM, cursor: "pointer", fontSize: 11, fontFamily: "monospace" }}>← ກັບຄືນ</button>
            <div>
              <div style={{ fontSize: 9, color: ACCENT, letterSpacing: 3 }}>ລາຍລະອຽດໜ່ວຍ</div>
              <div style={{ fontSize: 18, fontWeight: 900, color: TEXT }}>{selectedBranch.sheetName}</div>
            </div>
            <div style={{ marginLeft: "auto", textAlign: "right" }}>
              <div style={{ fontSize: 9, color: DIM }}>KPI ຄະແນນ</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: GOLD }}>{fmt(selectedBranch.kpiScore)}</div>
              <div style={{ fontSize: 9, color: DIM }}>{pctFmt(selectedBranch.kpiPlan > 0 ? selectedBranch.kpiScore / selectedBranch.kpiPlan : 0)} ຂອງແຜນ</div>
            </div>
          </div>

          {selectedBranch.detail ? (
            <>
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "18px 20px", marginBottom: 18 }}>
                <div style={{ fontSize: 10, color: DIM, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>ອັດຕາຕໍ່ຜະລິດຕະພັນ</div>
                <ResponsiveContainer width="100%" height={Math.max(200, selectedBranch.detail.products.length * 26)}>
                  <BarChart data={selectedBranch.detail.products.filter(p => p.plan > 0)} layout="vertical" margin={{ top: 0, right: 60, left: 20, bottom: 0 }}>
                    <XAxis type="number" tickFormatter={v => `${(v * 100).toFixed(0)}%`} tick={{ fill: DIM, fontSize: 10 }} axisLine={{ stroke: BORDER }} tickLine={false} />
                    <YAxis type="category" dataKey="name" width={160} tick={{ fill: "#A0B8C8", fontSize: 9 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 8, fontSize: 11 }}
                      formatter={(v) => [`${(v * 100).toFixed(1)}%`, "ອັດຕາ"]} />
                    <Bar dataKey="pct" radius={[0, 4, 4, 0]}>
                      {selectedBranch.detail.products.filter(p => p.plan > 0).map((p, i) => (
                        <Cell key={i} fill={pctColor(p.pct)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div style={{ background: CARD, border: `1px solid ${BORDER}`, borderRadius: 12, overflow: "hidden" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ background: "#0A1424" }}>
                      {["ຜະລິດຕະພັນ", "ປະຕິບັດ", "ແຜນ", "ອັດຕາ", "ສະຖານະ"].map((h, i) => (
                        <th key={i} style={{ padding: "10px 14px", textAlign: i === 0 ? "left" : "right", fontSize: 9, color: DIM, letterSpacing: 1, textTransform: "uppercase", fontWeight: 700 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {selectedBranch.detail.products.map((p, i) => {
                      const c = pctColor(p.pct);
                      return (
                        <tr key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                          <td style={{ padding: "8px 14px", fontSize: 11, color: "#C0D8E8" }}>{p.name}</td>
                          <td style={{ padding: "8px 14px", textAlign: "right", fontSize: 12, fontWeight: 700, color: TEXT }}>{fmt(p.actual)}</td>
                          <td style={{ padding: "8px 14px", textAlign: "right", fontSize: 11, color: DIM }}>{fmt(p.plan)}</td>
                          <td style={{ padding: "8px 14px", textAlign: "right", fontSize: 13, fontWeight: 900, color: c }}>{pctFmt(p.pct)}</td>
                          <td style={{ padding: "8px 14px", textAlign: "right" }}>
                            <Pill label={p.status || (p.pct >= 0.1667 ? "ເກີນແຜນ" : "ຫຼຸດແຜນ")} color={p.status === "ເກີນແຜນ" ? GREEN : c} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          ) : (
            <div style={{ color: DIM, textAlign: "center", padding: 40 }}>ບໍ່ພົບຂໍ້ມູນລາຍລະອຽດໃນ Sheet ນີ້</div>
          )}
        </div>
      )}

      {/* Footer */}
      <div style={{ marginTop: 28, borderTop: `1px solid ${BORDER}`, paddingTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 9, color: "#1A3050" }}>BCEL · ແຜນ 2026 · {fileName}</div>
        <div style={{ display: "flex", gap: 14, fontSize: 9 }}>
          <span style={{ color: GREEN }}>● ເກີນ ≥16.7%</span>
          <span style={{ color: GOLD }}>● 10–16.6%</span>
          <span style={{ color: RED }}>● ຕ່ຳ &lt;10%</span>
        </div>
      </div>
    </div>
  );
}
