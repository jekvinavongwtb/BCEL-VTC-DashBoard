# BCEL KPI Dashboard 2026

Dashboard ສຳລັບຕິດຕາມ KPI ໜ່ວຍບໍລິການ ນະຄອນຫຼວງວຽງຈັນ

## ວິທີ Deploy ຂຶ້ນ Vercel (ຟຣີ)

### ຂັ້ນຕອນທີ 1 — ສ້າງ GitHub Account
1. ໄປທີ່ https://github.com
2. ກົດ **Sign up** → ສ້າງ account ຟຣີ

### ຂັ້ນຕອນທີ 2 — Upload Project
1. Login GitHub → ກົດ **"New repository"** (ປຸ່ມສີຂຽວ)
2. ຕັ້ງຊື່: `bcel-dashboard`
3. ກົດ **Create repository**
4. ກົດ **"uploading an existing file"**
5. **ລາກໂຟລເດີ** `bcel-dashboard` ທັງໝົດໃສ່ → ກົດ **Commit changes**

### ຂັ້ນຕອນທີ 3 — Deploy ດ້ວຍ Vercel
1. ໄປທີ່ https://vercel.com
2. ກົດ **"Sign up"** → ເລືອກ **"Continue with GitHub"**
3. ກົດ **"Add New Project"**
4. ເລືອກ repo `bcel-dashboard` → ກົດ **Deploy**
5. ລໍຖ້າ ~1 ນາທີ → ໄດ້ URL ເຊັ່ນ: `bcel-dashboard.vercel.app` ✅

## ວິທີໃຊ້ງານ
- ເປີດ URL ໃນ browser ໃດກໍໄດ້ (PC, ມືຖື, tablet)
- ກົດ "Upload Excel" → ເລືອກໄຟລ `ຕິດຕາມຕົວເລກ...xlsx`
- Dashboard ຈະໂຫລດຂໍ້ມູນທັນທີ

## ການອັບເດດຂໍ້ມູນ
- ອັບ Excel ໃໝ່ຜ່ານ Dashboard ໄດ້ເລີຍ ບໍ່ຕ້ອງ redeploy
- ຖ້າຕ້ອງການ update code → push ຂຶ້ນ GitHub, Vercel auto-deploy

## ໂຄງສ້າງ Project
```
bcel-dashboard/
├── index.html          ← entry point
├── package.json        ← dependencies
├── vite.config.js      ← build config
├── vercel.json         ← deploy config
└── src/
    ├── main.jsx        ← React entry
    └── App.jsx         ← Dashboard code
```
